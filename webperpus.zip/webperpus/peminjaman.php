<h1 class="text-white mt-4">Laporan Peminjaman Buku</h1>
<div class="bg-dark card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12"> 
                <?php 
                // Periksa apakah pengguna yang login adalah anggota
                if ($_SESSION['t_user']['level'] == 'anggota') {
                    echo '<a href="?page=peminjaman_tambah" class="btn btn-primary row mb-2">+ Tambah Peminjaman</a>';
                }
                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tr class="text-white">
                        <th>No</th>
                        <th>ID User</th>
                        <th>Buku</th>
                        <th>Tanggal Peminjaman</th>
                        <th>Tanggal Pengembalian</th>
                        <th>Status Peminjaman</th>
                        <?php
                        // Periksa apakah pengguna yang login bukan anggota (petugas atau admin)
                        if ($_SESSION['t_user']['level'] != 'anggota') {
                            echo '<th>Aksi</th>';
                        }
                        ?>
                    </tr>
                    <?php
                    $i = 1;
                    $query = mysqli_query($koneksi, "SELECT * FROM t_peminjaman LEFT JOIN t_buku ON t_buku.bukuID = t_peminjaman.bukuID");

                    while($data = mysqli_fetch_array($query)){
                        ?>
                        <tr class="text-white">
                            <td><?php echo $i++; ?></td>
                            <td><?php echo $data['userID']; ?></td>
                            <td><?php echo $data['judul']; ?></td>
                            <td><?php echo $data['tgl_peminjaman']; ?></td>
                            <td><?php echo $data['tgl_pengembalian']; ?></td>
                            <td><?php echo $data['statusPeminjaman']; ?></td>
                            <?php
                            // Periksa apakah pengguna yang login bukan anggota (petugas atau admin)
                            if ($_SESSION['t_user']['level'] != 'anggota') {
                                echo '<td><a href="?page=peminjaman_ubah&&id='.$data['peminjamanID'].'" class="btn btn-info">Ubah</a></td>';
                            }
                            ?>
                        </tr>
                    <?php
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</div>

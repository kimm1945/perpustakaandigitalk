<?php
session_start();
$koneksi = mysqli_connect('localhost','id21792560_kimfreddykwon','kimFkwon321!','id21792560_kimfk');
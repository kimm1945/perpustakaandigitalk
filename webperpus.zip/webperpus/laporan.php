<h1 class="text-white mt-4">Laporan peminjaman</h1>
<div class="bg-dark card">
    <div class="card-body">
<div class="row">
   <div class="col-md-12"> 
       <a href="cetak.php" target="_blank" class="btn btn-primary mb-2"><i class="fa fa-print"></i>Cetak Data</a>
       <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <tr class="text-white">
            <th>No</th>
            <th>User</th>
            <th>Buku</th>
            <th>Tanggal Peminjaman</th>
            <th>Tanggal Pengembalian</th>
            <th>Status Peminjaman</th>
        </tr>
        <?php
         $i = 1;
            $query = mysqli_query($koneksi, "SELECT*FROM t_peminjaman LEFT JOIN t_user on t_user.userID = t_peminjaman.userID LEFT JOIN t_buku on t_buku.bukuID = t_peminjaman.bukuID");
            while($data = mysqli_fetch_array($query)){
                ?>
                <tr class="text-white">
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $data['username']; ?></td>
                    <td><?php echo $data['judul']; ?></td>
                    <td><?php echo $data['tgl_peminjaman']; ?></td>
                    <td><?php echo $data['tgl_pengembalian']; ?></td>
                    <td><?php echo $data['statusPeminjaman']; ?></td>
            </tr>
            <?php
            }
            ?>
            </table>
          </div>
        </div>
      </div>
   </div>